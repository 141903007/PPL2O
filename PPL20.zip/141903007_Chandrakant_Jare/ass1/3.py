
def sum_factors(n):
    result = []
    for i in range(1, int(n**0.5) + 1):
        if n % i == 0:
            result.extend([i, n//i])
    return sum(set(result)-set([n]))


def amicable(number):
    result = []
    for x in range(1, number + 1):
        y = sum_factors(x)
        if sum_factors(y) == x and x != y:
            result.append(tuple(sorted((x,y))))
    return set(result)

print(amicable(67000))








# {220: 284, 1184: 1210, 2620: 2924, 5020: 5564, 6232: 6368, 10744: 10856, 12285: 14595, 17296: 18416, 66928: 66992, 67095: 71145}
# {(10744, 10856), (5020, 5564), (2620, 2924), (1184, 1210), (12285, 14595), (17296, 18416), (66928, 66992), (63020, 76084), (6232, 6368), (220, 284)}







# count = 0
# i = 2
# sum = 0
# divisor = 0

# class my_dictionary(dict):
#     def __init__(self):
#         self = dict()

#     # Function to add key:value
#     def add(self, key, value):
#         self[key] = value


# # Main Function
# numbers = my_dictionary()

# pairs = my_dictionary()

# while count < 10:
#     sum = 0
#     for divisor in range(1, int(i/2 + 1)):
#         if (i % divisor) == 0:
#             sum = sum + divisor
#     pair_no = numbers.get(sum)
#     if pair_no == i:
#         pairs.add(sum, i)
#         count = count + 1
#     numbers.add(i, sum)
#     i = i + 1

# print(pairs)
