p_num = int(input("Enter number of pages. "))
l1 = list(range(1, p_num+1))
l2 = list(map(int,input("Enter  :").strip().split(",")))
'''print(type(l2)) 
l2 = list(map(int,input("Enter Pages:").strip().split(",")))[:p_num]
print(l2)''' 
def diff(l1, l2): 
    return (list(set(l1) - set(l2)))

out = diff(l1, l2)
print(out)


'''p_num = int(input("Enter number of pages. "))
l1 = list(range(1, p_num+1))
#l2 = [1,3,4,5-8, 10]
l2 = [1, 8-3]
print(l2)
def diff(l1, l2): 
    return (list(set(l1) - set(l2)))

out = diff(l1, l2)
print(out)'''




























# total_pages = int(input("Enter Total No of Pages:"))
# pages = input("Enter Pages:").split(",")

# def missing_numbers(lst):
#     return [x for x in range(0, total_pages + 1) if str(x) not in lst]

# for index in range(len(pages)):
#     if not pages[index].isnumeric():
#         r1, r2 = pages[index].split("-")
#         for i in range(int(r1),int(r2) + 1):
#             pages.append(str(i))
#         pages.remove(pages[index])
# pages.sort()
# missing_numbers = missing_numbers(pages)
# print("Missing Pages:",missing_numbers)