# def nthHarmonic(N) :  
#     harmonic = 1.00 
#     for i in range(2, N + 1) : 
#         harmonic += 1 / i 
#     return harmonic 
 
# N = 10
# print(round(nthHarmonic(N),5)) 


# def sum(n): 
#     s = 0.0
#     for i in range(1, n+1): 
#         s = s + 1/i; 
#     return s; 

# n = 10
# print("Sum is", round(sum(n), 6)) 
  


def sum(n): 
    s = 0
    total= 0
    l = []
    for i in range(1, n+1): 
        s =  s + (1/i) 
        l.append(s)
        total = total + s
    print(l)  
    print(f"Total of first {n} harmonic numbers is {total} ")
n = int(input("How many numbers you want ro proint: "))
sum(n)
