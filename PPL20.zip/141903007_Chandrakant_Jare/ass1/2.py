import random
run = "y"
while run == "y":
  print(random.randint(1, 6))
  run = input("Enter y for play dice again: ")
  if run == "n":
      break
  