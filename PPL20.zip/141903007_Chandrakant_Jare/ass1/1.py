print("First will be Goat ")
print("Second will be Grass But Goat will be take return to another side ")
print("Third will be Tiger ")
print("And finally Goat will be carry with the man")