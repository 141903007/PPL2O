def sumOfGP( a, r, n) : 
    l = []
    limit = 0
    while limit != n:
        if limit == 0:
            l.append(a)
        else:
            length = len(l)
            l.append(l[length-1]*r)
        limit = limit + 1
    return l

a = int(input("Enter first number: ")) 
r = int(input("Enter Difference of series: ")) 
n = int(input('Enter how many numbers you want to print: '))
  
print (sumOfGP(a, r, n))