x = int(input("Enter minimum value: "))
y = int(input("Enter maximum value: "))
sum1 = 0 
sum2 = 0

# for x in range(1,max):
#     for i in range(1,x):
#         if x % i == 0:
#             sum1 += i
#     for y in range(1,i):
#         for j in range(1,y):
#             if y % j == 0:
#                 sum2 += j
                
#             if(sum1 == y and sum2 == x):
#                 print(f"Amicable {x}, {y}")
#                 # else:
#                 #     print(f"not ambi {x}, {y}")



for i in range(1,x):
        if x % i == 0:
            sum1 += i

for j in range(1,y):
    if y % j == 0:
        sum2 += j
                
if(sum1 == y and sum2 == x):
    print(f"Amicable {x}, {y}")