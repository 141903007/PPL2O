import random
num = random.randint(1,100)
print(num)
count = 1
guess = int(input("Enter your guess: "))
while guess != num:
    if guess > num:
        print("You enter greater number: ")
        guess = int(input("Enter your guess: "))
        count = count + 1 
    elif guess < num:
        print("You enter small number: ")
        guess = int(input("Enter your guess: "))
        count = count + 1 
    if count == 5:
        break
  
if count < 5:
    print(f"Congratulations You win in {count} round: ")
else:
    print(f"You loss because you reach more than 5 count...")