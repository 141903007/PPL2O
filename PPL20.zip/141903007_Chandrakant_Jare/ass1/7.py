min = int(input("Enter minimum range: "))
max = int(input("Enter maximum range: "))
l = []
for num in range(min, max):
    temp = num
    sum = 0
    while temp > 0:
        digit = temp % 10
        sum = sum + digit ** 3
        temp = temp // 10
    if sum == num:
        # print(num)
        l.append(num)
print(l)
        
 