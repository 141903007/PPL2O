try:
   fh = open("Mydata.txt", "r")
   print(fh.read())
except IOError:
   print ("Error: can\'t find file or read data")
else:
   print ("Read content in the file successfully")
   fh.close()


def add(a,b):
    if type(a) == type(b):
         return a + b
    else:
        return "oops you are passing wrong data......"
#print(add(5,4))
print(add(5,"4"))



while True:
    try:
         x = int(input("Please enter a number: "))
         break
    except ValueError:
         print("Oops!  That was no valid number.  Try again...")
         raise TypeError("oops you are passing wrong data......")

try:
  print(y)
except NameError:
  print("Variable y is not defined")
except:
  print("Something else went wrong")