package com.siddhesh.attendancetaker;

public class Constants
{
    public static String KEY_USERNAME = "username";
    public static String KEY_PASSWORD = "password";

    public static String KEY_MEMBERID = "memberid";
    public static String KEY_FIRSTNAME = "firstname";
    public static String KEY_MIDDLENAME = "middlename";
    public static String KEY_LASTNAME = "lastname";
    public static String KEY_DOB = "dob";
    public static String KEY_AADHARNUMBER = "aadharnumber";
    public static String KEY_BLOODGROUP = "bloodgroup";
    public static String KEY_GENDER = "gender";
    public static String KEY_MOBILENO = "mobileno";
    public static String KEY_NEMNUK = "nemnuk";
    public static String KEY_LOGINID = "loginid";
    public static String KEY_DESIGNATION = "designation";

    public static String KEY_SECTORNAME = "secname";
    public static String KEY_SECTORHEAD = "sechead";
    public static String KEY_SECTORCOHEAD = "seccohead";
    public static String KEY_SECTORID = "sector";
    public static String KEY_DATE = "date";
}
