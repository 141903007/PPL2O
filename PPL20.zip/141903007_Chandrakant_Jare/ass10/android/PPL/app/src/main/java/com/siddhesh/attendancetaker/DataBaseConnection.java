package com.siddhesh.attendancetaker;

public class DataBaseConnection
{
    private static  final String ROOT_URL="https://zest20.000webhostapp.com/android/";

    public static final String URL_ROLE=ROOT_URL+"login.php";

    public static final String URL_MYATTENDANCE = ROOT_URL+"myAttendance.php";

    public static final String URL_CHANGEPASSWORD = ROOT_URL+"changePassword.php";

    public static final String URL_MEMBERS = ROOT_URL+"members.php";

    public static final String URL_MEMBERDETAILS = ROOT_URL+"memberDetails.php";

    public static final String URL_MYTEAM = ROOT_URL+"myTeam.php";

    public static final String URL_ATTENDENCE = ROOT_URL+"markAttendance.php";

    public static final String URL_REGISTER = ROOT_URL+"register.php";

}
