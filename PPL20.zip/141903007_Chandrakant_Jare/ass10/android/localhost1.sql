-- phpMyAdmin SQL Dump
-- version 4.9.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: May 28, 2020 at 03:39 PM
-- Server version: 10.3.16-MariaDB
-- PHP Version: 7.3.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `id11572970_android`
--
CREATE DATABASE IF NOT EXISTS `id11572970_android` DEFAULT CHARACTER SET utf8 COLLATE utf8_unicode_ci;
USE `id11572970_android`;

-- --------------------------------------------------------

--
-- Table structure for table `attendance`
--

CREATE TABLE `attendance` (
  `attendanceId` int(4) NOT NULL,
  `memberId` int(4) NOT NULL,
  `dateTime` datetime NOT NULL DEFAULT current_timestamp(),
  `latitude` double NOT NULL,
  `longitude` double NOT NULL,
  `location` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `checkedBy` int(4) NOT NULL,
  `status` varchar(20) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `attendance`
--

INSERT INTO `attendance` (`attendanceId`, `memberId`, `dateTime`, `latitude`, `longitude`, `location`, `checkedBy`, `status`) VALUES
(8, 2, '2020-05-25 07:49:16', 17.5, 17.5, 'India', 1, 'Present'),
(9, 4, '2020-05-25 07:50:40', 17.661558333333335, 75.31364833333333, 'Takli Road, Shriram Nagar, Pandharpur, Maharashtra 413304, India', 1, 'Absent'),
(10, 4, '2020-05-25 07:51:30', 17.661125000000002, 75.31580000000001, 'Takli Road, Shriram Nagar, Pandharpur, Maharashtra 413304, India', 1, 'Absent'),
(11, 2, '2020-05-25 07:51:50', 17.661125000000002, 75.31580000000001, 'Takli Road, Shriram Nagar, Pandharpur, Maharashtra 413304, India', 1, 'Present');

-- --------------------------------------------------------

--
-- Table structure for table `registration`
--

CREATE TABLE `registration` (
  `memberId` int(4) NOT NULL,
  `firstName` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `middleName` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `lastName` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `aadharNumber` decimal(12,0) NOT NULL,
  `mobileNo` decimal(20,0) NOT NULL,
  `password` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `designation` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `gender` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `dob` date NOT NULL,
  `bloodGroup` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `posting` varchar(20) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `registration`
--

INSERT INTO `registration` (`memberId`, `firstName`, `middleName`, `lastName`, `aadharNumber`, `mobileNo`, `password`, `designation`, `gender`, `dob`, `bloodGroup`, `posting`) VALUES
(1, 'Siddhesh', 'Jagadish', 'Khadake', 123456789012, 8237217213, '12345', 'PI', 'Male', '1999-09-21', 'AB+', 'Pandharpur'),
(2, 'Chandrakant', 'DontKnow', 'Jare', 987654321012, 9860444609, '12345', 'HC', 'Male', '1999-09-15', 'A+', 'Rajgad'),
(3, 'Snehal', 'Jagadish', 'Khadake', 543216789012, 9028771198, '12345', 'PN', 'Female', '1999-11-25', 'O+', 'Pune'),
(4, 'Vaibhavi', 'ABC', 'Ghumare', 321456789012, 8805754747, '12345', 'PC', 'Female', '1999-03-15', 'B+', 'Solapur'),
(5, 'ABC', 'EFG', 'HIJ', 942359195012, 9874563210, '12345', 'API', 'Female', '1999-01-01', 'O+', 'Maharashtra'),
(9, 'Andbd', 'bajaajaj', 'absjsja', 785236458791, 4567853349, '12345', 'PN', 'MALE', '2020-05-18', 'B+', 'Mumbai'),
(10, 'kajal ', 'narayan ', 'kumbharkar', 553289826460, 9139012529, 'password', 'PSI', 'FEMALE', '2000-01-01', 'B+', 'saswad'),
(11, 'Vaibhavi', 'Shahaji', 'Ghumare', 945476848464, 7387392017, 'Vaibhavi@28', 'PI', 'FEMALE', '2000-10-12', 'O-', 'Pune');

-- --------------------------------------------------------

--
-- Table structure for table `sector`
--

CREATE TABLE `sector` (
  `sectorIdList` int(11) NOT NULL,
  `sectorId` int(4) NOT NULL,
  `memberId` int(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `sector`
--

INSERT INTO `sector` (`sectorIdList`, `sectorId`, `memberId`) VALUES
(1, 1, 2),
(2, 1, 3),
(3, 1, 4),
(4, 1, 5),
(8, 1, 9),
(9, 1, 10);

-- --------------------------------------------------------

--
-- Table structure for table `sectorHead`
--

CREATE TABLE `sectorHead` (
  `sectorId` int(11) NOT NULL,
  `sectorHead` int(11) NOT NULL,
  `sectorCoHead` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `sectorHead`
--

INSERT INTO `sectorHead` (`sectorId`, `sectorHead`, `sectorCoHead`) VALUES
(1, 1, 1),
(1, 1, 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `attendance`
--
ALTER TABLE `attendance`
  ADD PRIMARY KEY (`attendanceId`);

--
-- Indexes for table `registration`
--
ALTER TABLE `registration`
  ADD PRIMARY KEY (`memberId`),
  ADD UNIQUE KEY `mobileNo` (`mobileNo`),
  ADD UNIQUE KEY `aadharNumber` (`aadharNumber`);

--
-- Indexes for table `sector`
--
ALTER TABLE `sector`
  ADD PRIMARY KEY (`sectorIdList`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `attendance`
--
ALTER TABLE `attendance`
  MODIFY `attendanceId` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `registration`
--
ALTER TABLE `registration`
  MODIFY `memberId` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `sector`
--
ALTER TABLE `sector`
  MODIFY `sectorIdList` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
