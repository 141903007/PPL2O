<?php
include 'db_connection.php';

$sectorId = "1";

$conn = OpenCon();

$array = array();

if(!empty($_POST)) {
    $sectorId = $_POST["sectorId"];
}

$sql = "SELECT memberId FROM sector WHERE sectorId = $sectorId";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
  while($row = $result->fetch_assoc()) {
      $temp = array();
      $temp['flag'] = "true";
      $temp['memberId'] = $row["memberId"];
      $reg = "SELECT firstName,middleName,lastName,designation,mobileNo,aadharNumber FROM registration WHERE memberId =" . $row['memberId'];
      $regres = $conn->query($reg);
      if ($regres->num_rows > 0) {
          while($row1 = $regres->fetch_assoc()) {
              $temp['name'] = $row1["firstName"] . " " . $row1["middleName"] . " " . $row1["lastName"];
              $temp['mobileNo'] = $row1["mobileNo"];
              $temp['aadharNumber'] = $row1["aadharNumber"];
              $temp['designation'] = $row1["designation"];
              array_push($array,$temp);
          }
      }
  }
}
else {
      $temp = array();
      $temp['flag'] = "true";
      array_push($array,$temp);
}

$data = array('myteam' => $array);

$json = json_encode($data); 

echo($json); 

CloseCon($conn);
?>