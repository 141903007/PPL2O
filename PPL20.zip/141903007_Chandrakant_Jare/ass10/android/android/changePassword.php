<?php
include 'db_connection.php';

$memberId = "1";
$currentPassword = "12345";
$newPassword = "12345";

$conn = OpenCon();

$array = array();

if(!empty($_POST)) {
    $memberId = $_POST["memberId"];
    $currentPassword = $_POST["currentPassword"];
    $newPassword = $_POST["newPassword"];
}

$sql = "SELECT password FROM registration WHERE memberId = $memberId";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
  while($row = $result->fetch_assoc()) {
      if($row['password'] == $currentPassword) {
         $sql = "UPDATE registration SET password = " . $newPassword . "  WHERE memberId = " . $memberId;
         if ($conn->query($sql) === TRUE) {
             $array['flag'] = "true";
         }
         else {
             $array['flag'] = "false";
         }
      }
      else {
          $array['flag'] = "false";
      }
  }
}
else {
    $array['flag'] = "false";
}

$data = array('changepassword' => $array);

$json = json_encode($data); 

echo($json); 

CloseCon($conn);
?>