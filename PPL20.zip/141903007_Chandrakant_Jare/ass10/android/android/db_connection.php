<?php
function OpenCon()
 {
 $dbhost = "localhost";
 $dbuser = "id11572970_root";
 $dbpass = "Admin@123456";
 $db = "id11572970_android";
 $conn = new mysqli($dbhost, $dbuser, $dbpass,$db) or die("Connect failed: %s\n". $conn -> error);
 
 return $conn;
 }
 
function CloseCon($conn)
 {
 $conn -> close();
 }
   
?>