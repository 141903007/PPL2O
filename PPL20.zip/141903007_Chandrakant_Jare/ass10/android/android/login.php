<?php
include 'db_connection.php';

$mobileNo = "8237217213";
$password = "12345";

$conn = OpenCon();

$array = array();

if(!empty($_POST)) {
    $mobileNo = $_POST["mobileNo"];
    $password = $_POST["password"];
}

$sql = "SELECT memberId, firstName, middleName, lastName, mobileNo, aadharNumber, dob, posting, designation, bloodGroup, gender  FROM registration WHERE mobileNo = $mobileNo && password = $password";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
  while($row = $result->fetch_assoc()) {
      $array['flag'] = "true";
      $array['memberId'] = $row["memberId"];
      $array['firstName'] = $row["firstName"];
      $array['middleName'] = $row["middleName"];
      $array['lastName'] = $row["lastName"];
      $array['mobileNo'] = $row["mobileNo"];
      $array['aadharNumber'] = $row["aadharNumber"];
      $array['dob'] = $row["dob"];
      $array['posting'] = $row["posting"];
      $array['designation'] = $row["designation"];
      $array['bloodGroup'] = $row["bloodGroup"];
      $array['gender'] = $row["gender"];
      $login = "SELECT sectorId FROM sectorHead WHERE ". $row['memberId'] . " = sectorHead OR " . $row['memberId'] . " = sectorCoHead";
      $loginres = $conn->query($login);
      if ($loginres->num_rows > 0) {
          $array['loginId'] = "1";
      }
      else {
          $array['loginId'] = "2";
      }
  }
} 
else {
  echo "0 results";
}

$data = array('logindata' => $array);

$json = json_encode($data); 

echo($json); 

CloseCon($conn);
?>