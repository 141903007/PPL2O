<?php
include 'db_connection.php';

$sectorId = "1";

$conn = OpenCon();

$array = array();

if(!empty($_POST)) {
    $sectorId = $_POST["sectorId"];
}

$sql = "SELECT memberId FROM sector WHERE sectorId = $sectorId";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    array_push($array,"true");
  while($row = $result->fetch_assoc()) {
      array_push($array,$row['memberId']);
  }
} 
else {
  echo "0 results";
}

$data = array('myteam' => $array);

$json = json_encode($data); 

echo($json); 

CloseCon($conn);
?>