<?php
include 'db_connection.php';

$location = "India";
$latitude = 17.5;
$longitude = 17.5;
$checkedBy = 1;
$status = "Present";
$memberId = 2;
$conn = OpenCon();

$array = array();

if(!empty($_POST)) {
    $memberId = $_POST["memberId"];
    $location = $_POST["location"];
    $latitude = $_POST["latitude"];
    $longitude = $_POST["longitude"];
    $checkedBy = $_POST["checkedBy"];
    $status = $_POST["status"];
}

$inssql = "INSERT INTO attendance(memberId,latitude,longitude,location,checkedBy,status) VALUES($memberId,$latitude,$longitude,'$location',$checkedBy,'$status')";
$insresult = $conn->query($inssql);
if ($insresult == TRUE) {
    $array['flag'] = "true";
    $array['memberId'] = $memberId;
}
else {
    $array['flag'] = "false";
}

$data = array('attendance' => $array);

$json = json_encode($data); 

echo($json); 

CloseCon($conn);
?>