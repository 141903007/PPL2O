<?php
include 'db_connection.php';

$memberId = 2;

$conn = OpenCon();

$array = array();

if(!empty($_POST)) {
    $memberId = $_POST["memberId"];
}

$sql = "SELECT checkedBy, location, status, dateTime FROM attendance WHERE memberId = $memberId";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
  while($row = $result->fetch_assoc()) {
      $temp = array();
      $temp['flag'] = "true";
      $temp['location'] = $row["location"];
      $temp['status'] = $row["status"];
      $temp['dateTime'] = $row["dateTime"];
      $mem = "SELECT firstName, lastName FROM registration WHERE memberId = " . $row['checkedBy'];
      $memres = $conn->query($mem);
      if ($memres->num_rows > 0) {
          while($rowmem = $memres->fetch_assoc()) {
                $temp['checkedBy'] = $rowmem['firstName'] . " " . $rowmem['lastName'];
          }
      }
      array_push($array,$temp);
  }
} 
else {
  echo "0 results";
}

$data = array('myattendance' => $array);

$json = json_encode($data); 

echo($json); 

CloseCon($conn);
?>