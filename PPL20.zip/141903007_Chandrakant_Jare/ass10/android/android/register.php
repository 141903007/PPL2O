<?php
include 'db_connection.php';

$firstName = "ABC";
$middleName = "EFG";
$lastName = "HIJ";
$dob = "1999-01-01";
$aadharNumber = "942359195012";
$mobileNo = "9874563210";
$gender = "Female";
$bloodGroup = "O+";
$designation = "API";
$nemnuk = "Maharashtra";
$password = "12345";

$conn = OpenCon();

$array = array();

if(!empty($_POST)) {
    $firstName = $_POST["firstName"];
    $middleName = $_POST["middleName"];
    $lastName = $_POST["lastName"];
    $dob = $_POST["dob"];
    $aadharNumber = $_POST["aadharNumber"];
    $mobileNo = $_POST["mobileNo"];
    $gender = $_POST["gender"];
    $bloodGroup = $_POST["bloodGroup"];
    $designation = $_POST["designation"];
    $nemnuk = $_POST["nemnuk"];
    $password = $_POST["password"];
}

$inssql = "INSERT INTO registration(firstName,middleName,lastName,aadharNumber,mobileNo,password,designation,gender,dob,bloodGroup,posting) VALUES('$firstName','$middleName','$lastName',$aadharNumber,$mobileNo,'$password','$designation','$gender','$dob','$bloodGroup','$nemnuk')";
$insresult = $conn->query($inssql);
if ($insresult == TRUE) {
    $array['flag'] = "true";
    $selsql = "SELECT memberId FROM registration WHERE mobileNo = $mobileNo && password = $password";
    $selresult = $conn->query($selsql);
    if ($selresult->num_rows > 0) {
        $array['flag'] = "true";
        while($row = $selresult->fetch_assoc()) {
            $memberId = $row['memberId'];
            $sql = "INSERT INTO sector(memberId, sectorId) VALUES($memberId,1)";
            $result = $conn->query($sql);
            if ($result == TRUE) {
                $array['flag'] = "true";
            }
            else {
                //echo "Error: " . $sql . "<br>" . $conn->error;
                $array['flag'] = "false";
            }
        }
    }
    else {
        //echo "Error: " . $selsql . "<br>" . $conn->error;
        $array['flag'] = "false";
    }
}
else {
    //echo "Error: " . $inssql . "<br>" . $conn->error;
    $array['flag'] = "false";
}

$data = array('register' => $array);

$json = json_encode($data); 

echo($json); 

CloseCon($conn);
?>