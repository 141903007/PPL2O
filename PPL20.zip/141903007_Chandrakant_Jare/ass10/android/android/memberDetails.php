<?php
include 'db_connection.php';

$memberId = "1";

$conn = OpenCon();

$array = array();

if(!empty($_POST)) {
    $memberId = $_POST["memberId"];
}

$sql = "SELECT memberId, firstName, middleName, lastName, mobileNo, aadharNumber, designation FROM registration WHERE memberId = $memberId";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
  while($row = $result->fetch_assoc()) {
      $array['flag'] = "true";
      $array['memberId'] = $row["memberId"];
      $array['name'] = $row["firstName"] . " " . $row["middleName"] . " " . $row["lastName"];
      $array['mobileNo'] = $row["mobileNo"];
      $array['aadharNumber'] = $row["aadharNumber"];
      $array['designation'] = $row["designation"];
  }
} 
else {
  echo "0 results";
}

$data = array('myteam' => $array);

$json = json_encode($data); 

echo($json); 

CloseCon($conn);
?>